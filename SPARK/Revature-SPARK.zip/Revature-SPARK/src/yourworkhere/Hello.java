package yourworkhere;

public class Hello {
    public static void main(String[] args) {
        System.out.println("New Horizon Financial");
        System.out.println("Est. 2003");
        System.out.println("");
        System.out.println("Unauthorized of this System is Punishable by Law");
    }
}
