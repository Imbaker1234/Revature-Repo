package com.revature.DungeonAndDragons;

public interface Sentient extends Creature {

    String speak();

}
