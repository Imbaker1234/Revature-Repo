package com.revature.DungeonAndDragons;

public interface Creature {
    boolean isAlive = true;
    int baseArmorClass = 10;
    int baseHP = 10;

    int unarmedAttack();
    int move();
    String makeSound();
}
