package com.revature.DungeonAndDragons;

public abstract class Elf implements Sentient {
    @Override
    public String speak() {
        return null;
    }

    @Override
    public int unarmedAttack() {
        return 0;
    }

    @Override
    public int move() {
        return 0;
    }

    @Override
    public String makeSound() {
        return null;
    }
}
