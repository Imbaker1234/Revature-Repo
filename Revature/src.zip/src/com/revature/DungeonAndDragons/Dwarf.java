package com.revature.DungeonAndDragons;

public abstract class
Dwarf {
}
