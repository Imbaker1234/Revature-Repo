package com.revature.DungeonAndDragons;

public interface Human {
}
