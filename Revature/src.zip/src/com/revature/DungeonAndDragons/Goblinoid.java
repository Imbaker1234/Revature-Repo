package com.revature.DungeonAndDragons;

public abstract class Goblinoid implements Sentient {
    boolean darkvision = true;
    boolean speaksGoblin = true;
}
