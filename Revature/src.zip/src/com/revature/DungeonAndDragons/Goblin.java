package com.revature.DungeonAndDragons;

public class Goblin extends Goblinoid {

    @Override
    public String speak() {
        return "Your GP or your HP!";
    }

    @Override
    public int unarmedAttack() {
        return 0;
    }

    @Override
    public int move() {
        return 0;
    }

    @Override
    public String makeSound() {
        return "I punch I kick I bite!";
    }
}
