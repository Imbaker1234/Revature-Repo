package com.revature.classtypes;

public class Driver {
    public static void main(String[] args) {
        Shark chompy = new Shark();

        chompy.swim();

        chompy.breathe();

        chompy.findPrey();


    }
}
