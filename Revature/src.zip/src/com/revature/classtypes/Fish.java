package com.revature.classtypes;

public abstract class Fish extends Animal {
    public abstract void swim();
}
